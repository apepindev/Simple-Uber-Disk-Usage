# Simple Übersicht Disk Space Widget

![Widget in action!](screenshot.png)

A simple widget to show current occupied space on your local drives.

To enable, place the `hddspace.widget` folder in your `Übersicht/widgets` directory.

Get more widgets at [Übersicht][1]!

[1]: http://tracesof.net/uebersicht-widgets/
